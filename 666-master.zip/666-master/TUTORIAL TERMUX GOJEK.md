______________________________________________
TUTORIAL TERMUX FOR GOJEK BY BANANACREAMY

SEBELUM PAKAI JGN LUPA FOLLOW IG @bananacreamy
______________________________________________
Yang masih ga bisa make termux buat voc ini , atau sblmnya gagal termux nya pake cara ini ya , ini untuk Sc yang github ya..


WAJIB Hapus data termux di pegaturan bila yang sudah make sc 666 yang sebelumnya, bila sudah masuk ke termux

$pkg install update && pkg install upgrade
$pkg install php
$pkg install curl
$pkg install git
$ git clone https://github.com/bananacreamy2/666
$cd 666
$php c.php

SUDAH PUNYA AKUN? y

BLANK HITAM (chat telegram)

MASUKAN NAMA 

HAPPY DOR GOJEK
______________________________________________
NOTE :

Urutin aja prosesnya, kadang ada muncul [continue? y/n] di beberapa step, nanti pilih "y"

Sekian terima kasih. 🥂
